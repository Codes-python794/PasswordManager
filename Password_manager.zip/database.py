import sqlite3

class Database:
    def __init__(self):
        self.con = sqlite3.connect("database.db")
        self.sq = self.con.cursor()
        self.database_db()
    def save_db(self):
        self.con.commit()
    def database_db(self):
        self.sq.execute("""
            CREATE TABLE IF NOT EXISTS websites(
                id_websites INTEGER PRIMARY KEY,
                name_websites TEXT,
                username_websites TEXT,
                password_websites TEXT,
                salt_data TEXT,
                nonce_data TEXT
            )
        """)
        self.save_db()