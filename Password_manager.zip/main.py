import database
import config

config.db = database.Database()

import crypt
config.crypt = crypt.Crypt()

import password_manager
config.manager = password_manager.Password_manager()
import ui