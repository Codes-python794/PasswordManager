import sys
from PySide6.QtWidgets import (
    QApplication,
    QWidget,
    QStackedWidget,
    QVBoxLayout,
    QLineEdit,
    QPushButton,
    QLabel,
    QMessageBox
)
import config

password_manager = config.manager

app = QApplication(sys.argv)

stack = QStackedWidget()
stack.setWindowTitle("Password manager")
stack.resize(600,400)

page_home = QWidget()
layout_home = QVBoxLayout(page_home)

page_add = QWidget()
layout_add = QVBoxLayout(page_add)

page_delete = QWidget()
layout_delete = QVBoxLayout(page_delete)

page_show = QWidget()
layout_show = QVBoxLayout(page_show)


def clear_layout(layout):
    while layout.count():
        item = layout.takeAt(0)

        if item.widget():
            item.widget().deleteLater()

        elif item.layout():
            clear_layout(item.layout())

def home():
    button_add = QPushButton("Add new website")
    button_show = QPushButton("Show all website")
    button_delete = QPushButton("Delete website")
    button_add.clicked.connect(lambda:stack.setCurrentIndex(1))
    button_show.clicked.connect(lambda:show_ui())
    button_delete.clicked.connect(lambda:stack.setCurrentIndex(3))
    layout_home.addWidget(button_add)
    layout_home.addWidget(button_show)
    layout_home.addWidget(button_delete)
def run_add(password_enter_encrypt,name_enter,username_enter,password_enter):
    password = password_enter_encrypt.text()
    name_web = name_enter.text()
    username_web = username_enter.text()
    password_web = password_enter.text()
    text = password_manager.add(password,name_web,username_web,password_web)
    message = QMessageBox.information(page_add,"Done",text)
    
def add_ui():
    password_enter_encrypt = QLineEdit()
    name_enter = QLineEdit()
    username_enter = QLineEdit()
    password_enter = QLineEdit()
    password_enter_encrypt.setPlaceholderText("Enter password for encrypt use password 1 only for decrypt and encrypt your accounts")
    name_enter.setPlaceholderText("Enter name website")
    username_enter.setPlaceholderText("Enter username website")
    password_enter.setPlaceholderText("Enter password website")
    button_add = QPushButton("Add is this account")
    button_back_add = QPushButton("Back home")
    button_add.clicked.connect(lambda:run_add(password_enter_encrypt,name_enter,username_enter,password_enter))
    button_back_add.clicked.connect(lambda:stack.setCurrentIndex(0))
    layout_add.addWidget(password_enter_encrypt)
    layout_add.addWidget(name_enter)
    layout_add.addWidget(username_enter)
    layout_add.addWidget(password_enter)
    layout_add.addWidget(button_add)
    layout_add.addWidget(button_back_add)

def run_show(password):
    clear_layout(layout_show)
    data_get = password_manager.show(password)
    if data_get == "You enter password wrong":
        message = QMessageBox.information(page_show,"Error",data_get)
    else:
        show_data = QLabel(data_get)
        layout_show.addWidget(show_data)
    button_back_show = QPushButton("Back home")
    button_back_show.clicked.connect(lambda:stack.setCurrentIndex(0))
    layout_show.addWidget(button_back_show)


def show_ui():
    clear_layout(layout_show)
    stack.setCurrentIndex(2)
    button_show_all = QPushButton("Show all")
    password = QLineEdit()
    password.setPlaceholderText("Enter password")
    button_show_all.clicked.connect(lambda:run_show(password.text()))
    button_back_show = QPushButton("Back home")
    button_back_show.clicked.connect(lambda:stack.setCurrentIndex(0))
    layout_show.addWidget(password)
    layout_show.addWidget(button_show_all)
    layout_show.addWidget(button_back_show)

def run_delete(id_get):
    message = QMessageBox.information(page_delete,"Done",password_manager.delete(int(id_get.text())))
def delete_ui():
    id_get = QLineEdit()
    id_get.setPlaceholderText("Enter id website")
    button_delete = QPushButton("Delete is this account")
    button_delete.clicked.connect(lambda:run_delete(id_get))
    button_back_delete = QPushButton("Back home")
    button_back_delete.clicked.connect(lambda:stack.setCurrentIndex(0))
    layout_delete.addWidget(id_get)
    layout_delete.addWidget(button_delete)
    layout_delete.addWidget(button_back_delete)


home()
add_ui()
delete_ui()

stack.addWidget(page_home)
stack.addWidget(page_add)
stack.addWidget(page_show)
stack.addWidget(page_delete)
stack.show()
sys.exit(app.exec())