import config

class Password_manager:
    def __init__(self):
        self.db = config.db
        self.crypt = config.crypt
    def add(self,password,name_website,username_website,password_website):
        name_encrypt,username_encrypt,password_encrypt,salt,nonce = self.crypt.encrypt(password,name_website,username_website,password_website)
        self.db.sq.execute("INSERT INTO websites(name_websites,username_websites,password_websites,salt_data,nonce_data) VALUES (?,?,?,?,?)",(name_encrypt,username_encrypt,password_encrypt,salt,nonce))
        self.db.save_db()
        return "Done add is it account"
    def delete(self,id_get):
        self.db.sq.execute("SELECT name_websites FROM websites WHERE id_websites = ?",(id_get,))
        check_found = self.db.sq.fetchone()
        if not check_found:
            return "Dosin's found it's website"
        elif check_found:
            self.db.sq.execute("DELETE FROM websites WHERE id_websites = ?",(id_get,))
            self.db.save_db()
            return "Done delete is it website"

    def show(self,password_get):
        self.db.sq.execute("SELECT * FROM websites")
        show = self.db.sq.fetchall()
        data_return = ""
        for data in show:
            data_check = self.crypt.decrypt(data[0],data[1],data[2],data[3],password_get,data[4],data[5])
            if data_check == "You enter password wrong":
                return data_check
            elif isinstance(data_check,dict):
                data_return += f"Id website: {data[0]} | Nmae website: {data_check[data[0]]["name"]} | Username website: {data_check[data[0]]["username"]} | Password website: {data_check[data[0]]["password"]}\n"
        return data_return