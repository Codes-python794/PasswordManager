# Password Manager | مدير كلمات المرور

**[English](#english) | [العربية](#arabic)**

---

<a id="english"></a>

# Password Manager

A simple desktop password manager written in Python. It has a graphical interface built with **PySide6**, stores data in a local **SQLite** database, and encrypts every entry with **AES-256-GCM**, using a key derived from your master password with **Argon2id**.

## Features

- Add a website account (website name, username, password)
- Show all saved accounts (decrypted with your master password)
- Delete an account by its ID
- All fields are encrypted before being written to the database
- Everything is stored locally in `database.db`, with no network access

## Project structure

| File | Description |
|------|-------------|
| `main.py` | Entry point. Creates the database, crypto and manager objects, then loads the UI |
| `ui.py` | PySide6 graphical interface (home, add, show, delete pages) |
| `password_manager.py` | Logic for adding, deleting and showing accounts |
| `crypt.py` | Key derivation (Argon2id) and encryption/decryption (AES-GCM) |
| `database.py` | SQLite connection and `websites` table creation |
| `config.py` | Shared global objects (`db`, `crypt`, `manager`) |
| `requirements.txt` | Python dependencies |

## Requirements

- Python **3.12 or newer**
- Packages listed in `requirements.txt`: `argon2-cffi`, `cryptography`, `PySide6`

## Installation

```bash
# 1. (Optional) create a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
```

## Usage

Run the program from inside the project folder (the database file is created in the current working directory):

```bash
python main.py
```

1. **Add new website**: enter your master password, then the website name, username and password, and press *Add is this account*.
2. **Show all website**: enter your master password and press *Show all* to see the decrypted list with IDs.
3. **Delete website**: enter the ID of the entry (shown in the list) and press *Delete is this account*.

> Use the **same master password** every time. It is the only way to decrypt your data, and it is not stored anywhere. If you lose it, your data cannot be recovered.

## How it works

1. A random 16-byte salt is generated for each entry.
2. The master password and salt are passed through **Argon2id** (time cost 5, memory 40,000 KiB, parallelism 4) to produce a 32-byte key.
3. The website name, username and password are encrypted with **AES-GCM** using that key.
4. The encrypted fields, the salt and the nonce are saved in the `websites` table.
5. To show data, the key is re-derived from the master password and each entry's salt, and the data is decrypted. A wrong password raises an authentication error (`InvalidTag`), and the app shows "You enter password wrong".

## Database schema

```
websites(
    id_websites        INTEGER PRIMARY KEY,
    name_websites      TEXT,   -- encrypted
    username_websites  TEXT,   -- encrypted
    password_websites  TEXT,   -- encrypted
    salt_data          TEXT,
    nonce_data         TEXT
)
```

## Known limitations and suggested improvements

- **Nonce reuse:** the same nonce is used to encrypt the three fields of an entry with the same key. This is unsafe for AES-GCM. Use a separate random nonce for each field.
- **No master password check when adding:** a typo while adding creates an entry that needs the mistyped password to decrypt, and "Show all" will then fail with "wrong password" for the whole list. Consider a confirmation field or a stored verifier.
- **Mixed master passwords:** because each entry has its own salt and may have been encrypted with a different password, one wrong entry blocks showing all the others.
- Passwords are displayed in plain text on screen and are not copied to the clipboard securely.
- Entering a non-numeric ID in the delete page will raise an error.

## License

No license specified. Add one before sharing publicly.

---

<a id="arabic"></a>

<div dir="rtl">

# مدير كلمات المرور (Password Manager)

برنامج مكتبي بسيط لإدارة كلمات المرور مكتوب بلغة Python. واجهته الرسومية مبنية بـ **PySide6**، وبيحفظ البيانات في قاعدة بيانات **SQLite** محلية، وبيشفّر كل حساب بخوارزمية **AES-256-GCM** باستخدام مفتاح مشتق من كلمة المرور الرئيسية عن طريق **Argon2id**.

## المميزات

- إضافة حساب لموقع (اسم الموقع، اسم المستخدم، كلمة المرور)
- عرض كل الحسابات المحفوظة (بعد فك التشفير بكلمة المرور الرئيسية)
- حذف حساب باستخدام رقم الـ ID بتاعه
- كل الحقول بتتشفّر قبل ما تتحفظ في قاعدة البيانات
- كل حاجة بتتخزن محليًا في ملف `database.db` من غير أي اتصال بالإنترنت

## هيكل المشروع

| الملف | الوصف |
|------|-------------|
| `main.py` | نقطة البداية. بينشئ قاعدة البيانات وكائنات التشفير والمدير، وبعدين بيشغّل الواجهة |
| `ui.py` | الواجهة الرسومية بـ PySide6 (الصفحة الرئيسية، الإضافة، العرض، الحذف) |
| `password_manager.py` | منطق إضافة وحذف وعرض الحسابات |
| `crypt.py` | اشتقاق المفتاح (Argon2id) والتشفير وفك التشفير (AES-GCM) |
| `database.py` | الاتصال بـ SQLite وإنشاء جدول `websites` |
| `config.py` | الكائنات المشتركة (`db` و`crypt` و`manager`) |
| `requirements.txt` | المكتبات المطلوبة |

## المتطلبات

- Python **الإصدار 3.12 أو أحدث**
- المكتبات الموجودة في `requirements.txt`: ‏`argon2-cffi` و`cryptography` و`PySide6`

## التثبيت

```bash
# 1. (اختياري) إنشاء بيئة افتراضية
python -m venv venv
source venv/bin/activate        # على ويندوز: venv\Scripts\activate

# 2. تثبيت المكتبات
pip install -r requirements.txt
```

## الاستخدام

شغّل البرنامج من جوه فولدر المشروع (ملف قاعدة البيانات بيتعمل في المجلد الحالي):

```bash
python main.py
```

1. **Add new website**: اكتب كلمة المرور الرئيسية، وبعدها اسم الموقع واسم المستخدم وكلمة المرور، واضغط *Add is this account*.
2. **Show all website**: اكتب كلمة المرور الرئيسية واضغط *Show all* عشان تشوف القائمة بعد فك التشفير مع الـ IDs.
3. **Delete website**: اكتب الـ ID الخاص بالحساب (ظاهر في القائمة) واضغط *Delete is this account*.

> استخدم **نفس كلمة المرور الرئيسية** في كل مرة. هي الطريقة الوحيدة لفك تشفير بياناتك، وهي مش متخزنة في أي مكان. لو نسيتها مش هتقدر تسترجع بياناتك.

## إزاي بيشتغل؟

1. بيتولّد salt عشوائي طوله 16 بايت لكل حساب.
2. كلمة المرور الرئيسية مع الـ salt بيعدّوا على **Argon2id** (time cost = 5، memory = 40,000 كيلوبايت، parallelism = 4) لإنتاج مفتاح طوله 32 بايت.
3. اسم الموقع واسم المستخدم وكلمة المرور بيتشفّروا بـ **AES-GCM** باستخدام المفتاح ده.
4. الحقول المشفّرة والـ salt والـ nonce بيتحفظوا في جدول `websites`.
5. وقت العرض، بيتم اشتقاق المفتاح من جديد من كلمة المرور والـ salt الخاص بكل حساب، وبعدين بتتفك التشفير. لو كلمة المرور غلط بيحصل خطأ في التحقق (`InvalidTag`) والبرنامج بيعرض "You enter password wrong".

## مخطط قاعدة البيانات

```
websites(
    id_websites        INTEGER PRIMARY KEY,
    name_websites      TEXT,   -- مشفّر
    username_websites  TEXT,   -- مشفّر
    password_websites  TEXT,   -- مشفّر
    salt_data          TEXT,
    nonce_data         TEXT
)
```

## ملاحظات وتحسينات مقترحة

- **إعادة استخدام الـ nonce:** نفس الـ nonce بيتستخدم لتشفير الحقول التلاتة في الحساب الواحد بنفس المفتاح، وده مش آمن مع AES-GCM. الأفضل استخدام nonce عشوائي منفصل لكل حقل.
- **مفيش تأكيد لكلمة المرور الرئيسية عند الإضافة:** لو غلطت في كتابتها وقت الإضافة، الحساب ده هيحتاج نفس الكلمة الغلط عشان يتفك، وهتلاقي "Show all" بتفشل برسالة "wrong password" للقائمة كلها. ممكن تضيف حقل تأكيد أو طريقة للتحقق.
- **اختلاف كلمات المرور:** عشان كل حساب له salt خاص وممكن يكون متشفّر بكلمة مختلفة، حساب واحد غلط بيمنع عرض باقي الحسابات.
- كلمات المرور بتتعرض كنص عادي على الشاشة ومفيش نسخ آمن للـ clipboard.
- لو دخلت ID مش رقم في صفحة الحذف هيحصل خطأ.

## الترخيص

مفيش ترخيص محدد. ضيف واحد قبل ما تشارك المشروع علنًا.

</div>
