password = None
manager = None
db = None
crypt = None