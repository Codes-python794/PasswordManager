import os
from argon2.low_level import hash_secret_raw,Type
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag
import config

class Crypt:
    def __init__(self):
        self.db = config.db
    def create_key(self,password):
        salt = os.urandom(16)
        key = hash_secret_raw(
            password.encode(),
            salt,
            time_cost=5,
            memory_cost=40000,
            parallelism=4,
            hash_len=32,
            type=Type.ID,
        )
        return key,salt
    def get_key(self,password,salt):
        key = hash_secret_raw(
            password.encode(),
            salt,
            time_cost=5,
            memory_cost=40000,
            parallelism=4,
            hash_len=32,
            type=Type.ID,
        )
        return key
    def encrypt(self,password,name_web,username_web,password_web):
        key,salt = self.create_key(password)
        nonce = os.urandom(12)
        name_encrypt = AESGCM(key).encrypt(nonce,name_web.encode(),None)
        username_encrypt = AESGCM(key).encrypt(nonce,username_web.encode(),None)
        password_encrypt = AESGCM(key).encrypt(nonce,password_web.encode(),None)
        return name_encrypt,username_encrypt,password_encrypt,salt,nonce
    def decrypt(self,id_get,name_web,username_web,password_web,password,salt,nonce):
        try:
            key = self.get_key(password,salt)
            name_decrypt = AESGCM(key).decrypt(nonce,name_web,None)
            username_decrypt = AESGCM(key).decrypt(nonce,username_web,None)
            password_decrypt = AESGCM(key).decrypt(nonce,password_web,None)
            data_send = {}
            data_send[id_get] = {
                "name":name_decrypt.decode(),
                "username":username_decrypt.decode(),
                "password":password_decrypt.decode()
            }
            return data_send
        except InvalidTag:
            return "You enter password wrong"